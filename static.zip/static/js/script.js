document.getElementById('fileInput').addEventListener('change', function(event) {
  const files = event.target.files;
  if (files.length > 0) {
      const formData = new FormData();
      formData.append('file', files[0]);

      // Display the uploaded file in the containerArea
      const containerArea = document.getElementById('containerArea');
      containerArea.innerHTML = ''; // Clear previous content

      const file = files[0];
      const reader = new FileReader();
      
      reader.onload = function(e) {
          const img = document.createElement('img');
          img.src = e.target.result;
          img.alt = file.name;
          img.style.maxWidth = '15%'; // Adjust size as needed
          containerArea.appendChild(img);
      };

      reader.readAsDataURL(file); // Read the file as a data URL

      // Send the file to the server
      fetch('/predict', {
          method: 'POST',
          body: formData
      })
      .then(response => response.json())
      .then(data => {
          if (data.error) {
              document.getElementById('predictionResults').innerText = `Error: ${data.error}`;
          } else {
              document.getElementById('predictionResults').innerText = `Prediction: ${data.prediction}`;
          }
      })
      .catch(error => {
          document.getElementById('predictionResults').innerText = `Error: ${error.message}`;
      });
  }
});
